
module.exports = {
  content: ["./src/app/**/*.{ts,tsx}", "./src/components/**/*.{ts,tsx}"],
  theme: { extend: {
    keyframes: { ticker: {'0%':{transform:'translateX(0)'}, '100%':{transform:'translateX(-100%)'}} },
    animation: { ticker: 'ticker 18s linear infinite' }
  } },
  plugins: []
}
