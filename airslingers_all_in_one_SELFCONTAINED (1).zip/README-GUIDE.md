
# AirSlingers – Sådan gør du (Windows)
1) Installer Node: https://nodejs.org/en (grøn LTS) og genstart.
2) Dobbeltklik MAKE_ENV_AND_EDIT_WINDOWS.bat → indsæt dine Stripe nøgler i .env.local og gem.
3) Dobbeltklik RUN_WINDOWS.bat → vent til der står Local: http://localhost:3000 → åbn linket.
4) Når du er klar til online: redigér PUSH_TO_GITHUB_WINDOWS.bat (dit repo-URL) → dobbeltklik → importér i Vercel → Deploy.
5) Læg dit domæne www.airslingers.com ind i Vercel → følg DNS-instruktioner.

Konkurrence: Sæt din Formspree URL i src/app/contest/page.tsx (to steder).
PWA: Allerede aktiveret (manifest + service worker).
