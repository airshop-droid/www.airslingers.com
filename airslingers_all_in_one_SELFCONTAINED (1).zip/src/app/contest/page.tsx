
"use client";
import { useState } from "react";
import { useI18n } from "@/lib/i18n";
const CATS=[{id:"guitar",label:"Air Guitar"},{id:"drums",label:"Air Drums"},{id:"flute",label:"Air Flute"},{id:"trumpet",label:"Air Trumpet"},{id:"mic",label:"Air Microphone"}];
export default function Contest(){
  const { t } = useI18n();
  const [submitted,setSubmitted]=useState(false);
  const [ratingSent,setRatingSent]=useState(false);
  return (
    <div className="container my-10">
      <h1 className="text-3xl font-extrabold">{t("contest_title")}</h1>
      <p className="text-[var(--muted)] mt-2">{t("contest_intro")}</p>
      <div className="grid md:grid-cols-2 gap-6 mt-6">
        <div className="card">
          <h3 className="text-xl font-semibold mb-3">Indsend din video</h3>
          {submitted? <div className="text-green-400">✅ {t("thanks")}</div> : (
            <form action="REPLACE_WITH_FORMSPREE_URL" method="POST" onSubmit={()=>setSubmitted(true)} className="grid gap-3">
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-sm text-[var(--muted)]">{t("name")}</label><input name="name" required className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2"/></div>
                <div><label className="text-sm text-[var(--muted)]">{t("email")}</label><input name="email" type="email" required className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2"/></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-sm text-[var(--muted)]">{t("category")}</label>
                  <select name="category" required className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2">
                    <option value="">—</option>
                    {CATS.map(c=> <option key={c.id} value={c.id}>{c.label}</option>)}
                  </select>
                </div>
                <div><label className="text-sm text-[var(--muted)]">{t("video")}</label>
                  <input name="video_url" type="url" required placeholder="https://..." className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2"/>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-sm text-[var(--muted)]">{t("music")}</label><input name="music" className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2"/></div>
                <div className="flex items-center gap-2"><input id="merch" name="merch_bonus" type="checkbox" value="yes" className="h-4 w-4"/><label htmlFor="merch" className="text-sm">{t("merch_bonus")}</label></div>
              </div>
              <div><label className="text-sm text-[var(--muted)]">{t("note")}</label><textarea name="note" rows={3} className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2"/></div>
              <div className="text-xs text-[var(--muted)]">* Video må max være 30 sekunder. Ved at indsende accepterer du reglerne.</div>
              <button className="btn mt-1">{t("submit")}</button>
            </form>
          )}
        </div>

        <div className="card">
          <h3 className="text-xl font-semibold mb-3">{t("like_title")}</h3>
          {ratingSent? <div className="text-green-400">✅ Tak for din rating!</div> : (
            <form action="REPLACE_WITH_FORMSPREE_URL_RATING" method="POST" onSubmit={()=>setRatingSent(true)} className="grid gap-3">
              <div><label className="text-sm text-[var(--muted)]">Video-link</label><input name="video_url" type="url" required placeholder="https://..." className="w-full rounded-md border border-[var(--border)] bg-transparent px-3 py-2"/></div>
              <div className="flex items-center gap-2"><label className="text-sm text-[var(--muted)]">Stjerner (1–5)</label>
                <select name="stars" required className="rounded-md border border-[var(--border)] bg-transparent px-2 py-1">
                  <option value="5">★★★★★ – {t("rate_1")}</option>
                  <option value="4">★★★★ – {t("rate_2")}</option>
                  <option value="3">★★★ – {t("rate_3")}</option>
                  <option value="2">★★ – {t("rate_4")}</option>
                  <option value="1">★ – {t("rate_5")}</option>
                </select>
              </div>
              <button className="btn mt-1">Send rating</button>
            </form>
          )}
          <div className="mt-4 text-sm text-[var(--muted)]">* Ratings gemmes via Formspree. Du kan eksportere til regneark og finde vindere.</div>
        </div>
      </div>

      <section className="mt-10">
        <h2 className="text-2xl font-bold">{t("rules")}</h2>
        <ul className="list-disc pl-5 mt-3 space-y-2 text-[var(--muted)]">
          <li>Periode: 1. oktober – 1. december (tilpas selv).</li>
          <li>Kategorier: Guitar, Trommer, Fløjte, Trompet, Mikrofon.</li>
          <li>Video: Max 30 sek. (brug musik du synes passer).</li>
          <li>Point: Showmanship, Sync, Kreativitet, Humor (0–10) + 10 bonus med T-shirt/Hoodie.</li>
          <li>Præmier: 1: stor merch + gavekort 499 · 2: merch + gavekort 399 · 3: merch + gavekort 299 · 4–10: merch-overraskelse.</li>
        </ul>
      </section>
    </div>
  );
}
