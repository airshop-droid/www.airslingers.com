
import { products } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import Reviews from "@/components/Reviews";
import BannerSlideshow from "@/components/BannerSlideshow";
import { useI18n } from "@/lib/i18n";

export default function Home(){
  const { t } = useI18n();
  const cats = Array.from(new Set(products.map(p=>p.category)));
  return (
    <div className="container">
      <BannerSlideshow />
      <section className="my-10 text-center">
        <h1 className="text-4xl font-extrabold">{t("hero_t")}</h1>
        <p className="text-[var(--muted)] mt-2">{t("hero_s")}</p>
      </section>
      {cats.map(c=>(
        <section key={c} className="my-10">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">{c}</h2>
            <a href="/checkout" className="text-sm text-[var(--muted)] hover:underline">{t("go_checkout")}</a>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-4">
            {products.filter(p=>p.category===c).map(p=> <ProductCard key={p.id} p={p}/>)}
          </div>
        </section>
      ))}
      <Reviews />
    </div>
  );
}
