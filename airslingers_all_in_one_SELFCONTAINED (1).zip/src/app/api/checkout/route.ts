
import { NextResponse } from "next/server";
import Stripe from "stripe";
export async function POST(req: Request){
  const body = await req.json();
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2024-06-20" as any });
  if (!process.env.STRIPE_SECRET_KEY || !process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY){
    return NextResponse.json({ error: "Stripe keys missing" }, { status: 400 });
  }
  const line_items = (body.items||[]).map((i:any)=>({
    price_data:{ currency:"dkk", product_data:{ name:i.name }, unit_amount: i.dkk*100 }, quantity: i.qty
  }));
  const session = await stripe.checkout.sessions.create({
    mode:"payment", payment_method_types:["card","mobilepay"], line_items,
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/?success=1`,
    cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/checkout?canceled=1`,
    locale:"da-DK"
  });
  return NextResponse.json({ id: session.id });
}
