
import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import CartProvider from "@/components/CartContext";
import MerchNote from "@/components/MerchNote";
import { I18nProvider } from "@/lib/i18n";

export const metadata: Metadata = {
  title: "www.airslingers.com – Air Instruments Webshop",
  description: "Grand Opening 299/399/499 DKK — air guitars, drums, flutes, trumpets, microphones & merch.",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icons/icon-192.png", apple: "/icons/icon-192.png" }
};

export default function RootLayout({ children }:{ children:React.ReactNode }){
  return (
    <html lang="da">
      <body>
        <I18nProvider>
          <CartProvider>
            <Header />
            <main>{children}</main>
            <footer className="container py-12 text-sm text-[var(--muted)]">
              © {new Date().getFullYear()} www.airslingers.com · Imagination, fun and 100% silence
            </footer>
            <MerchNote />
          </CartProvider>
        </I18nProvider>
      </body>
    </html>
  );
}
