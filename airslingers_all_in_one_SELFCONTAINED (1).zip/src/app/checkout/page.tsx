
"use client";
import { useCart } from "@/components/CartContext";
import { useI18n, fmtCurrency } from "@/lib/i18n";
import { loadStripe } from "@stripe/stripe-js";
import { useState } from "react";
export default function Checkout(){
  const { items, totalDKK, remove, setQty, clear } = useCart();
  const { t, rate } = useI18n();
  const [loading,setLoading]=useState(false);
  const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "");
  const pay = async () => {
    setLoading(true);
    try{
      const res = await fetch("/api/checkout", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ items }) });
      const data = await res.json();
      const stripe = await stripePromise;
      if (stripe) {
        const { error } = await stripe.redirectToCheckout({ sessionId: data.id });
        if (error) alert(error.message);
      } else alert("Stripe not configured.");
    }catch(e:any){ alert(e.message||"Error"); }
    finally{ setLoading(false); }
  };
  const totalFx = rate(totalDKK);
  return (
    <div className="container my-10">
      <h1 className="text-3xl font-bold">Checkout</h1>
      {items.length===0 ? (<p className="text-[var(--muted)] mt-2">{t("empty")}</p>) : (
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          <div className="md:col-span-2 card">
            <h2 className="text-xl font-semibold">{t("cart")}</h2>
            <ul className="mt-4 space-y-4">
              {items.map(i=>{
                const fx = rate(i.dkk);
                return (
                  <li key={i.id} className="flex items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="font-semibold">{i.name}</div>
                      <div className="text-sm text-[var(--muted)]">{fmtCurrency(fx.amount, fx.code)} · {t("opening")}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="number" min={1} value={i.qty} onChange={e=>setQty(i.id, parseInt(e.target.value||'1'))} className="w-16 rounded-md border border-[var(--border)] bg-transparent px-2 py-1"/>
                      <button onClick={()=>remove(i.id)} className="text-red-400 text-sm">Remove</button>
                    </div>
                  </li>
                );
              })}
            </ul>
            <button onClick={clear} className="mt-3 text-sm text-[var(--muted)] underline">Clear</button>
          </div>
          <div className="card">
            <h2 className="text-xl font-semibold">Payment</h2>
            <div className="mt-3 flex items-center justify-between"><span className="text-[var(--muted)]">{t("subtotal")}</span><span>{fmtCurrency(totalFx.amount, totalFx.code)}</span></div>
            <div className="mt-1 flex items-center justify-between"><span className="text-[var(--muted)]">{t("shipping")}</span><span>{t("shipping_free")}</span></div>
            <div className="mt-1 flex items-center justify-between"><span className="text-[var(--muted)]">{t("discount")}</span><span>{t("discount_inc")}</span></div>
            <div className="mt-3 flex items-center justify-between text-lg font-bold"><span>{t("total")}</span><span>{fmtCurrency(totalFx.amount, totalFx.code)}</span></div>
            <button disabled={loading} onClick={pay} className="btn w-full mt-4">{loading? "Redirecting..." : t("pay_stripe")}</button>
            <div className="mt-3 text-center text-sm text-[var(--muted)]">{t("paypal_hint")}</div>
          </div>
        </div>
      )}
    </div>
  );
}
