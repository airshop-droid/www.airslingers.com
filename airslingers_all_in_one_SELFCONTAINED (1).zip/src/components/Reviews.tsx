
export default function Reviews(){
  const reviews = Array.from({length: 12}).map((_,i)=>({ name:`Fan #${i+1}`, rating: 5 - (i%3===0?1:0), text:"Rocked my living room! 100% silent, 200% fun." }));
  return (
    <section id="reviews" className="container my-16">
      <h2 className="text-2xl font-bold mb-6">Reviews ({reviews.length})</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {reviews.map((r,i)=>(
          <div key={i} className="card">
            <div className="flex items-center justify-between">
              <div className="font-semibold">{r.name}</div>
              <div>{"★".repeat(r.rating)}{"☆".repeat(5-r.rating)}</div>
            </div>
            <p className="text-sm text-[var(--muted)] mt-2">{r.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
