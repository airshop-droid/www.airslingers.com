
"use client";
import Image from "next/image";
import type { Product } from "@/lib/products";
import { useCart } from "./CartContext";
import { useI18n, fmtCurrency } from "@/lib/i18n";
export default function ProductCard({ p }:{ p:Product }){
  const { add } = useCart();
  const { t, rate } = useI18n();
  const before = rate(p.beforePrice);
  const now = rate(p.price);
  return (
    <div className="card h-full flex flex-col">
      <div className="relative w-full aspect-[8/5] overflow-hidden rounded-xl border border-[var(--border)] bg-black">
        <Image src={p.image} alt={p.name} fill className="object-cover" />
      </div>
      <div className="mt-4 flex-1 flex flex-col">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-lg font-semibold">{p.name}</h3>
          <span className="badge">{p.category}</span>
        </div>
        <p className="text-sm text-[var(--muted)] mt-2">{p.description}</p>
        <div className="mt-3 text-sm">
          <div><span className="strike mr-2">{fmtCurrency(before.amount, before.code)}</span><span className="font-bold">{fmtCurrency(now.amount, now.code)}</span></div>
          <div className="text-xs text-[var(--muted)]">{t("opening")} · {t("save")} {fmtCurrency(before.amount-now.amount, now.code)}</div>
        </div>
        <button onClick={()=>add(p)} className="btn mt-4">{t("add")}</button>
      </div>
    </div>
  );
}
