
"use client";
import Link from "next/link";
import { useCart } from "./CartContext";
import { useI18n } from "@/lib/i18n";
const LANGS = [["da","DA"],["en","EN"],["sv","SV"],["no","NO"],["de","DE"],["fr","FR"],["es","ES"],["it","IT"],["nl","NL"]];
const CURRENCIES = ["DKK","EUR","USD","GBP","SEK","NOK"] as const;
export default function Header(){
  const { totalDKK } = useCart();
  const { t, lang, setLang, currency, setCurrency, rate } = useI18n();
  const r = rate(totalDKK);
  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-black/40 border-b border-[var(--border)]">
      <div className="container flex items-center justify-between py-4">
        <Link href="/" className="text-lg font-bold">www.airslingers<span className="text-[var(--accent)]">.com</span></Link>
        <nav className="hidden md:flex gap-6 text-sm text-[var(--muted)]">
          <Link href="/">{t("products")}</Link>
          <Link href="/checkout">{t("checkout")}</Link>
          <Link href="/contest">{t("contest")}</Link>
          <a href="#reviews">{t("reviews")}</a>
        </nav>
        <div className="flex items-center gap-2">
          <select aria-label="Language" value={lang} onChange={e=>setLang(e.target.value as any)} className="bg-transparent text-xs border border-[var(--border)] rounded px-2 py-1 text-[var(--muted)]">
            {LANGS.map(([code,label])=> <option key={code} value={code}>{label}</option>)}
          </select>
          <select aria-label="Currency" value={currency} onChange={e=>setCurrency(e.target.value)} className="bg-transparent text-xs border border-[var(--border)] rounded px-2 py-1 text-[var(--muted)]">
            {CURRENCIES.map(c=> <option key={c} value={c}>{c}</option>)}
          </select>
          <Link href="/checkout" className="btn text-xs">{t("cart")} · {new Intl.NumberFormat('da-DK',{style:'currency',currency:'DKK',maximumFractionDigits:0}).format(totalDKK)} / {new Intl.NumberFormat(undefined,{style:'currency',currency:r.code,maximumFractionDigits:0}).format(r.amount)}</Link>
        </div>
      </div>
    </header>
  );
}
