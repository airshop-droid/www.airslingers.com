
"use client";
import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
export default function MerchNote(){
  const [open,setOpen]=useState(false);
  const { t } = useI18n();
  useEffect(()=>{ const onKey=(e:KeyboardEvent)=>{ if(e.key==='Escape') setOpen(false); }; document.addEventListener('keydown',onKey); return ()=>document.removeEventListener('keydown',onKey); },[]);
  return (<>
    <button onClick={()=>setOpen(true)} className="fixed right-0 top-1/3 z-50 bg-[var(--accent)] text-black px-4 py-2 rounded-l-xl shadow-lg rotate-[-90deg] origin-bottom-right">{t("merch_tab")}</button>
    {open && <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" onClick={()=>setOpen(false)} />}
    {open && (
      <div className="fixed inset-0 z-[61] grid place-items-center p-4">
        <div className="card max-w-lg w-full relative">
          <button onClick={()=>setOpen(false)} className="absolute right-3 top-3 text-sm text-[var(--muted)]">✕</button>
          <div className="inline-flex items-center gap-2 text-black bg-[var(--accent)] rounded-lg px-3 py-1 font-bold">🎁 {t("opening")} + merch</div>
          <h3 className="text-xl font-extrabold mt-3">{t("merch_title")}</h3>
          <p className="text-[var(--muted)] mt-2">{t("merch_body")}</p>
          <ul className="mt-4 list-disc pl-5 space-y-2 text-sm">
            <li>“Certified Air Musician” T-shirt</li>
            <li>AirSlingers Gig Bag</li>
            <li>Holo stickers</li>
            <li>Enamel pins (2-pack)</li>
            <li>A3 poster</li>
          </ul>
          <div className="mt-3 text-xs text-[var(--muted)]">{t("merch_note")}</div>
          <button onClick={()=>setOpen(false)} className="btn mt-4">{t("merch_back")}</button>
        </div>
      </div>
    )}
  </>);
}
