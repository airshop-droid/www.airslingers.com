
"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
const banners = ["/images/banner-dk.png","/images/banner-dk-fire.png","/images/banner-en.png","/images/banner-clean.png","/images/banner-clean-alt.png"];
export default function BannerSlideshow(){
  const [i,setI]=useState(0);
  useEffect(()=>{ const id=setInterval(()=>setI(v=>(v+1)%banners.length),5000); return ()=>clearInterval(id); },[]);
  return (<div className="relative w-full h-[480px] overflow-hidden rounded-2xl mb-8 border border-[var(--border)]"><Image src={banners[i]} alt="Banner" fill className="object-cover" priority/></div>);
}
