
"use client";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { Product } from "@/lib/products";
type Item = { id:string; name:string; qty:number; dkk:number };
type Cart = { items:Item[]; add:(p:Product)=>void; remove:(id:string)=>void; setQty:(id:string,q:number)=>void; clear:()=>void; totalDKK:number; };
const Ctx = createContext<Cart|null>(null);
export default function CartProvider({children}:{children:React.ReactNode}){
  const [items,setItems]=useState<Item[]>([]);
  useEffect(()=>{ const raw=localStorage.getItem("cart:v1"); if(raw) setItems(JSON.parse(raw)); },[]);
  useEffect(()=>{ localStorage.setItem("cart:v1", JSON.stringify(items)); },[items]);
  const add=(p:Product)=> setItems(prev=>{ const f=prev.find(i=>i.id===p.id); return f? prev.map(i=>i.id===p.id?{...i,qty:i.qty+1}:i):[...prev,{id:p.id,name:p.name,qty:1,dkk:p.price}] });
  const remove=(id:string)=> setItems(prev=>prev.filter(i=>i.id!==id));
  const setQty=(id:string,q:number)=> setItems(prev=>prev.map(i=>i.id===id?{...i,qty:q||1}:i));
  const clear=()=> setItems([]);
  const totalDKK = useMemo(()=> items.reduce((a,b)=>a+b.dkk*b.qty,0),[items]);
  return <Ctx.Provider value={{items,add,remove,setQty,clear,totalDKK}}>{children}</Ctx.Provider>;
}
export const useCart=()=>{ const c=useContext(Ctx); if(!c) throw new Error("useCart"); return c; }
