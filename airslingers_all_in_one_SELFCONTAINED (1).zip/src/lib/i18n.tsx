
"use client";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
export type Lang = "da"|"en"|"sv"|"no"|"de"|"fr"|"es"|"it"|"nl";
type Dict = Record<string,string>;
const dicts: Record<Lang, Dict> = {
  da:{ brand:"www.airslingers.com",products:"Produkter",checkout:"Checkout",reviews:"Anmeldelser",
       hero_t:"www.airslingers.com – Åbningstilbud",hero_s:"Alle varer på 299 / 399 / 499 kr · Fri fantasi, nul larm.",
       go_checkout:"Gå til checkout →",opening:"Åbningstilbud",save:"Spar",cart:"Kurv",empty:"Din kurv er tom.",
       subtotal:"Subtotal",shipping:"Fragt",shipping_free:"0 kr",discount:"Rabat",discount_inc:"Allerede indregnet",total:"Total",
       pay_stripe:"Betal med kort / MobilePay (Stripe)",paypal_hint:"PayPal kan tilføjes senere.",footer:"Fantasi, sjov og 100% stilhed",
       merch_tab:"🎁 Merch med i købet",merch_title:"Merch følger med hvert luftinstrument",merch_body:"Hver ordre inkluderer mindst én merch-gave.",
       merch_note:"*Gaver varierer. Ekstra ved bundles.",merch_back:"Tilbage til shoppen",add:"Køb nu",contest:"Konkurrence",winners:"Vindere",
       contest_title:"AirSlingers Konkurrence – vis din luftperformance (max 30 sek)",contest_intro:"Upload din video (YouTube/TikTok/Instagram – max 30 sek), indsæt linket, vælg kategori. Bonuspoint hvis du bærer T-shirt eller Hoodie.",
       name:"Navn",email:"E-mail",category:"Kategori",video:"Video-link",music:"Musik (valgfri)",merch_bonus:"Jeg bærer AirSlingers T-shirt eller Hoodie (bonus)",
       note:"Kommentar (valgfri)",submit:"Indsend til konkurrencen",thanks:"Tak! Din deltagelse er registreret.",rules:"Regler & præmier",
       like_title:"Publikumsrating",rate_1:"Elskede det!",rate_2:"Rigtig godt",rate_3:"Godt",rate_4:"Ok",rate_5:"Kunne være bedre" },
  en:{ brand:"www.airslingers.com",products:"Products",checkout:"Checkout",reviews:"Reviews",
       hero_t:"www.airslingers.com – Grand Opening",hero_s:"All items at 299 / 399 / 499 DKK · Full imagination, zero noise.",
       go_checkout:"Go to checkout →",opening:"Opening Offer",save:"Save",cart:"Cart",empty:"Your cart is empty.",subtotal:"Subtotal",
       shipping:"Shipping",shipping_free:"0",discount:"Discount",discount_inc:"Already included",total:"Total",
       pay_stripe:"Pay by card / MobilePay (Stripe)",paypal_hint:"PayPal can be added later.",footer:"Imagination, fun and 100% silence",
       merch_tab:"🎁 Merch included",merch_title:"Merch is included with every air instrument",merch_body:"Every order includes at least one merch gift.",
       merch_note:"*Gifts vary. Extra in bundles.",merch_back:"Back to shop",add:"Add to cart",contest:"Contest",winners:"Winners",
       contest_title:"AirSlingers Contest – show your air performance (max 30s)",contest_intro:"Upload your video (YouTube/TikTok/Instagram – max 30s), paste the link, choose a category. Bonus points if wearing our T-shirt or Hoodie.",
       name:"Name",email:"Email",category:"Category",video:"Video link",music:"Music (optional)",merch_bonus:"I’m wearing an AirSlingers T-shirt or Hoodie (bonus)",
       note:"Note (optional)",submit:"Submit to contest",thanks:"Thanks! Your entry has been recorded.",rules:"Rules & Prizes",
       like_title:"Audience rating",rate_1:"Loved it!",rate_2:"Really good",rate_3:"Good",rate_4:"Okay",rate_5:"Could be better" }
};
type Ctx = { lang:Lang; setLang:(l:Lang)=>void; t:(k:string)=>string; currency:string; setCurrency:(c:string)=>void; rate:(dkk:number)=>{amount:number,code:string}; };
const CtxX = createContext<Ctx|null>(null);
const RATES: Record<string, number> = { DKK:1, EUR:0.134, USD:0.144, GBP:0.113, SEK:1.53, NOK:1.53 };
export function I18nProvider({children}:{children:React.ReactNode}){
  const [lang,setLang]=useState<Lang>('da');
  const [currency,setCurrency]=useState('DKK');
  useEffect(()=>{
    const s=localStorage.getItem('lang:v1') as Lang|null;
    const c=localStorage.getItem('currency:v1');
    if(s) setLang(s);
    if(c) setCurrency(c); else {
      const loc=navigator.language||'en';
      if(loc.startsWith('da')){setLang('da');setCurrency('DKK');}
      else if(loc.startsWith('sv')){setLang('sv');setCurrency('SEK');}
      else if(loc.startsWith('no')){setLang('no');setCurrency('NOK');}
      else if(loc.startsWith('de')){setLang('de');setCurrency('EUR');}
      else {setLang('en');setCurrency('USD');}
    }
  },[]);
  useEffect(()=>{ localStorage.setItem('lang:v1',lang); },[lang]);
  useEffect(()=>{ localStorage.setItem('currency:v1',currency); },[currency]);
  const t=(k:string)=> (dicts[lang]&&dicts[lang][k]) || dicts['en'][k] || k;
  const rate=(dkk:number)=>{ const r=RATES[currency]??1; return {amount:Math.round(dkk*r), code:currency}; };
  const v = useMemo(()=>({lang,setLang,t,currency,setCurrency,rate}),[lang,currency]);
  return <CtxX.Provider value={v}>{children}</CtxX.Provider>;
}
export function useI18n(){ const c=useContext(CtxX); if(!c) throw new Error("useI18n"); return c; }
export function fmtCurrency(amount:number, code:string){
  const loc = code==='DKK'?'da-DK': code==='USD'?'en-US': code==='EUR'?'de-DE': code==='GBP'?'en-GB': code==='SEK'?'sv-SE': code==='NOK'?'no-NO':'en-US';
  return new Intl.NumberFormat(loc,{style:'currency',currency:code,maximumFractionDigits:0}).format(amount);
}
