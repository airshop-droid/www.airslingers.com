export const products = [
  {
    "id": "phantom-axe-3000",
    "name": "The Phantom Axe 3000",
    "category": "Guitar",
    "beforePrice": 1199,
    "price": 499,
    "description": "Invisible bestseller with raw attitude. Zero tuning \u2013 pure rock.",
    "image": "/images/phantom-axe-3000.svg"
  },
  {
    "id": "breezecaster-deluxe",
    "name": "The BreezeCaster Deluxe",
    "category": "Guitar",
    "beforePrice": 899,
    "price": 399,
    "description": "Light as air, heavy as rock. Switch styles instantly.",
    "image": "/images/breezecaster-deluxe.svg"
  },
  {
    "id": "thunderstrummer-x",
    "name": "Thunderstrummer X",
    "category": "Guitar",
    "beforePrice": 1299,
    "price": 499,
    "description": "Harness thunder for arena-ready riffs.",
    "image": "/images/thunderstrummer-x.svg"
  },
  {
    "id": "cyclone-drums",
    "name": "The Cyclone Drums",
    "category": "Drums",
    "beforePrice": 1199,
    "price": 499,
    "description": "Command storms with silent power.",
    "image": "/images/cyclone-drums.svg"
  },
  {
    "id": "zen-percussion-clouds",
    "name": "Zen Percussion Clouds",
    "category": "Drums",
    "beforePrice": 799,
    "price": 299,
    "description": "Meditative percussion for calm & focus.",
    "image": "/images/zen-percussion-clouds.svg"
  },
  {
    "id": "whisperwind-5000",
    "name": "WhisperWind 5000",
    "category": "Flute",
    "beforePrice": 899,
    "price": 299,
    "description": "Your breath, turned into art.",
    "image": "/images/whisperwind-5000.svg"
  },
  {
    "id": "thunderhorn-supreme",
    "name": "ThunderHorn Supreme",
    "category": "Trumpet",
    "beforePrice": 899,
    "price": 399,
    "description": "Epic fanfares that shake the room (not the neighbors).",
    "image": "/images/thunderhorn-supreme.svg"
  },
  {
    "id": "power-roar-mic",
    "name": "Power Roar Mic",
    "category": "Microphone",
    "beforePrice": 999,
    "price": 499,
    "description": "Sing louder than silence \u2013 arena energy.",
    "image": "/images/power-roar-mic.svg"
  },
  {
    "id": "tshirt-certified-air",
    "name": "T-shirt: Certified Air Musician",
    "category": "Merch",
    "beforePrice": 349,
    "price": 299,
    "description": "Unisex tee with iconic print.",
    "image": "/images/tshirt-certified-air.svg"
  },
  {
    "id": "gig-bag",
    "name": "AirSlingers Gig Bag",
    "category": "Merch",
    "beforePrice": 329,
    "price": 299,
    "description": "Carry your \u2018air\u2019 gear in style.",
    "image": "/images/gig-bag.svg"
  }
] as const;
export type Product = typeof products[number];
